using Terraria.ModLoader;

namespace COMDAR
{
	public class COMDAR : Mod
	{
	}
}